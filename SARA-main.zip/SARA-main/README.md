<img title="SARA" src="https://img.shields.io/badge/CODENAME%20-SARA-SCRIPT?colorA=grey&colorB=green&style=for-the-badge"> <img title="SARA" src="https://img.shields.io/badge/VERSION%20-2.0-SCRIPT?colorA=grey&colorB=green&style=for-the-badge"> 
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/overview.jpg">
### SARA - Simple Android Ransomware Attack
A simple tool for making android ransomware
### Disclaimer
The author is not responsible for any loses or damage caused by this program.
### Sara Decryptor
Download Decrypter APK's for Sara Ransomware version 2.0 [Click Here](https://drive.google.com/file/d/1hODfBdHRBw3Tyn8RhM-Zv8D3b7KFoLnt/view?usp=drivesdk)
#### SARA version 1.0
- ```app_icon``` - custom icon application
- ```app_name``` - custom name application
- ```alert_title``` - custom alert title
- ```alert_desc``` - custom alert description
- ```key_pass``` - custom key for unlock devices
#### SARA version 2.0
- ```app_icon``` - custom icon application
- ```app_name``` - custom name application
- ```app_desc``` - custom desctription (README.txt)
### Installation
Quick installation for Ubuntu, Kali Linux, Darwin (MAC)
```bash
git clone https://github.com/termuxhackers-id/SARA && cd SARA && sudo bash install.sh
```

Quick installation for Termux Android
````bash
git clone https://github.com/termuxhackers-id/SARA && cd SARA && bash installtermux.sh
````
### Dependencies
- Java
  - Openjdk 17
- Aapt
- Apktool
  - Apktool 2.6.1
- Zipalign
- Imagemagick
- Python3
- Python3-pip
  - Pillow
### Tools overview
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/toolview.png"></img>
### SARA - version 1.0
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/v1.jpg"></img>
```Tested on Android 10```
### SARA - version 2.0 
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/v2.jpg"></img>
```Tested on Android 7.1```
### Output logs
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/output.jpg"></img>
Now users can share their ransomware via the link

### Support Us
Facebook [@termuxhackers.id](https://fb.me/termuxhackers.id)<br>
Instagram [@termuxhackers.id](https://instagram.com/termuxhackers.id)

### Credit's
Copyright © 2021 by [Termux Hackers](https://github.com/termuxhackers-id)
