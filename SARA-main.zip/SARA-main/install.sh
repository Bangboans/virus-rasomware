#! /usr/bin/bash
sudo apt-get install default-jdk -y
sudo apt-get install aapt zipalign -y
sudo apt-get install apktool -y
sudo apt-get install imagemagick -y
sudo apt-get install python3 python3-pip -y
pip3 install Pillow
